# Sparrow game and Studio (first version, 15 Nov 2026)

Double-click **`Sparrow Studio.bat`** in the workspace folder. Everything else is reachable from that window.
(`Play Sparrow.bat` goes straight to the game.)

## Play

Click the 3D window first.

| Keyboard | Controller (Xbox-style) | Move |
|---|---|---|
| UP (hold) | left stick up | walk, about 160 mm/s |
| SHIFT + UP | stick fully up | fast walk, about 200 mm/s |
| LEFT / RIGHT (hold) | stick left / right | steer while walking (gentle) |
| SPACE | A | hop, about 44 mm clearance |
| SHIFT + SPACE | X | far hop, about 60 mm forward |
| ENTER | B | jump, about 60 mm clearance |
| SHIFT + ENTER | Y | high jump, about 100 mm clearance |
| R | START | reset |
| C | | camera: chase / side |

The bird stops walking before it hops, and waits 0.8 s after landing before walking again. If it falls it resets after 3 s.

## Train

Train tab: pick a skill, press **Start training**. Each run tries settings in simulation, keeps the best, and saves a
*candidate*. Nothing changes in the game until you select a candidate and press **Promote to the game**; the previous
skills file is backed up and **Undo last promote** puts it back. **Try it in the game** plays a candidate without promoting.

| Skill | What is scored |
|---|---|
| walk, fast_walk | speed without falling |
| steer | degrees turned in 5 s of walking |
| pivot | turning on the spot (experimental, off by default) |
| reverse | walking backwards (experimental, off by default) |
| jump_height | jump to a target clearance in mm |
| hop_distance | far hop to a target distance in mm |

Every candidate is then checked on 5 robot conditions and on the full 45 s routine, and the list shows both results.
At most 2 jobs run at once, and none start while CPU or memory is above 85%.

## Files

- `play.py` the game window · `pilot.py` turns commands into joint targets · `world.py` shared simulation loop
- `train.py` trainer (`list`, `run`, `validate`, `promote`, `restore`) · `selftest.py` headless routine · `studio.py` the window
- `skills.json` the skills in use, with where each came from · `candidates/` trained results · `skills_backups/` · `logs/`

## What is true today

- Model: `v7e_bispring` copy (hip-and-knee jump spring). Simulation only, with the placeholder servo behaviour the
  validated hops used. Realistic servo drag, compliant couplings and the larger flight wing are not in the game yet.
- Full routine (walk, hop, turns, jump, fast walk, high jump, hop while walking): 4 of 5 conditions complete it; the
  heavier robot (+7%) falls during a turn.
- Steering is weak: the legs only pitch, so 5 s of full steer bends the path by a few degrees. Turning on the spot
  reaches 10-20 degrees in 5 s but stayed up only 6-7 times in 10; walking backwards stayed up 1-4 times in 5. Both are
  switched off and are training targets.
- "Fast walk" is not a true run: there is no flight phase.
- Flight is not in the game. The flight studies are separate calculations with a prescribed body angle.
- The window, keyboard and HUD were exercised with a scripted bot; a controller was not available to test.
